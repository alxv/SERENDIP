#=====================================Authors============================== 
#Alexandar vincent paulraj, Lauren walker,Frans coenen, Munir pirmoahmed,Girvan burnside. 
#University of Liverpool. UK
#Publication - https://livrepository.liverpool.ac.uk/3140162/
#==========================================================================
#Libraries
library(shiny)
library(data.table)
library(dplyr)
library(lubridate)
library(stringi)
library(stringr)
library(DT)
library(formattable)
library(shinythemes)
library(shinybrowser)
#=========================================================================
shinyUI(fluidPage(theme = shinytheme("cerulean"),
                  tags$head(tags$style(".progress-bar{background-color:#fe1153;}")),
                  
                  navbarPage('SERENDIP',
                             tabPanel(title = "Home", value = "home",
                                      shinybrowser::detect(),
                                      HTML('<center><img src="back1.png" ></center>')
                                      
                             ),
                             tabPanel(title = "Analyse", value = "analysis", 
                                      
                                      wellPanel(fileInput("file1", "Choose the file",multiple = FALSE,
                                                          accept = c(".csv")
                                      )),
                                      h4('Download'),
                                      HTML('<hr style="color: blue;">'),
                                      fluidRow(uiOutput('Master_results')),
                                      h4('Results'),
                                      HTML('<hr style="color: blue;">'),
                                      dataTableOutput('viewresults')
                             ),
                             tabPanel(title = 'Documentation', value = 'tutorial',
                                      #tags$iframe(width="900", height="500", src="Tutorial_serendip_v2.mp4", frameborder="0", allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture", allowfullscreen=T),
                                      h4('Example data'),
                                      p("id=numeric/string/both.date= dd/mm/yyyy.item=name of the event (avoid special characters)",style="text-align:justify;color:black;background-color:papayawhip;padding:15px;border-radius:10px"),
                                      downloadButton("demodata", "Download sample data")
                             ),  
                             tabPanel(title = 'Team', value = 'team',br(),
                                      #tableOutput('userData'),
                                      HTML('<center><img src="Team.jpg" ></center>')
                             ),
                             tabPanel(title = 'Feedback', value = 'feedback',br(),
                                      div(id = "loginpage", style = "width: 500px; max-width: 100%; margin: 0 auto; padding: 20px;background-color:#282e54;",
                                          wellPanel(shinyjs::useShinyjs(),id='wells',
                                                    tags$h2("WE WELCOME YOUR FEEDBACK", class = "text-center", style = "padding-top: 0;color:#333; font-weight:600;"),
                                                    textInput("nameuser", label = tagList(icon("user"), "Name")),
                                                    textInput("emailuser",label = tagList(icon("envelope-square"), "E-mail")),
                                                    textInput("orguser", label = tagList(icon("landmark"), "Organisation ")),
                                                    textAreaInput('message',placeholder="type..", label = tagList(icon("comment-dots"), "Message "), resize = 'none',height = '50px'),
                                                    actionButton("submit", "Submit",
                                                                 style = "color: green; 
                                                         background-color: #4d3a7d; 
                                                         position: relative; 
                                                         left: 40%;
                                                         height: 35px;
                                                         width: 70px;
                                                         text-align:center;
                                                         text-indent: -2px;
                                                         border-width: 3px" ),br()
                                          ),br()),
                                      shinyjs::hidden(
                                        div(
                                          id = "thankyou_msg",
                                          h3("Thanks, your response was submitted successfully!")
                                        )
                                      ) 
                             )
                  )))
